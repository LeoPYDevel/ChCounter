import tkinter as tk
from tkinter import filedialog
from tkinter import ttk

def contar_caracteres(event=None):
    texto = texto_entrada.get("1.0", "end-1c")
    cantidad_caracteres = len(texto)
    label_resultado.config(text=f"Cantidad de caracteres: {cantidad_caracteres}")

    if cantidad_caracteres > 50:
        scrollbar_y.grid(row=0, column=1, sticky="ns")
    else:
        scrollbar_y.grid_forget()

    if cantidad_caracteres > 80:
        scrollbar_x.grid(row=1, column=0, sticky="ew")
    else:
        scrollbar_x.grid_forget()

def cargar_documento():
    ruta_documento = filedialog.askopenfilename(filetypes=[("Archivos de texto", "*.txt")])
    if ruta_documento:
        with open(ruta_documento, "r") as archivo:
            texto = archivo.read()
            texto_entrada.delete("1.0", "end")
            texto_entrada.insert("1.0", texto)
        contar_caracteres()

def seleccionar_todo(event):
    texto_entrada.tag_add("sel", "1.0", "end")

def copiar(event):
    texto_entrada.event_generate("<<Copy>>")

def pegar(event):
    texto_entrada.event_generate("<<Paste>>")

def cortar(event):
    texto_entrada.event_generate("<<Cut>>")

# Crear la ventana principal
ventana = tk.Tk()
ventana.title("Contador de Caracteres")
ventana.geometry("600x400") #600 50
ventana.resizable(False, False)

# Modificar el estilo de los widgets
estilo = ttk.Style()
estilo.configure('TButton', padding=5, relief="flat", background="#d9d9d9")
estilo.configure('TLabel', padding=5)
barra_menus = tk.Menu()
# Crear el primer menú.
menu_archivo = tk.Menu(barra_menus, tearoff=False)
# Agregarlo a la barra.
barra_menus.add_cascade(menu=menu_archivo, label="Archivo")
ventana.config(menu=barra_menus)

# Agregar opciones al menú "Archivo"
menu_archivo.add_command(label="Cargar Archivo", command=cargar_documento)
menu_archivo.add_command(label="Contar Caracteres", command=contar_caracteres)

# Crear el campo de texto
texto_entrada = tk.Text(ventana, wrap="char")
texto_entrada.grid(row=0, column=0, padx=10, pady=10, sticky="nsew")
texto_entrada.bind("<Control-a>", seleccionar_todo)
texto_entrada.bind("<Control-c>", copiar)
texto_entrada.bind("<Control-v>", pegar)
texto_entrada.bind("<Control-x>", cortar)

# Crear deslizadores
scrollbar_y = tk.Scrollbar(ventana, command=texto_entrada.yview)
scrollbar_x = tk.Scrollbar(ventana, command=texto_entrada.xview, orient="horizontal")

# Botón para contar caracteres
boton_contar = ttk.Button(ventana, text="Contar Caracteres", command=contar_caracteres)
boton_contar.grid(row=1, column=0, padx=10, pady=10, sticky="w")

# Etiqueta para mostrar el resultado
label_resultado = ttk.Label(ventana, text="Cantidad de caracteres: 0")
label_resultado.grid(row=2, column=0, padx=10, pady=10)

# Botón para cargar documento
boton_cargar = ttk.Button(ventana, text="Cargar Documento", command=cargar_documento)
boton_cargar.grid(row=1, column=0, padx=10, pady=10, sticky="e")

# Configurar el grid
ventana.grid_rowconfigure(0, weight=1)
ventana.grid_columnconfigure(0, weight=1)

# Llamar a la función contar_caracteres al inicio para configurar los deslizadores
contar_caracteres()

# Centrar el label en la parte inferior
label_resultado.place(relx=0.5, rely=1, anchor="s")

ventana.mainloop()
